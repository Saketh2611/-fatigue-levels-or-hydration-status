# README: Hydration Status Prediction Using ML

## 📌 Project Overview
This mini-project aims to develop a predictive model that classifies a person's **hydration status** (Well, Borderline, Dehydrated) using physiological and lifestyle features. The model is built using both **Random Forest** and **XGBoost**, showcasing supervised learning, feature selection, and evaluation.

---

## 🧾 Dataset Description
A synthetic dataset was created to simulate real-world physiological data. Each record includes the following features:

- **Age** (years)
- **Gender** (Male/Female)
- **HeartRate** (beats per minute)
- **SkinTemp** (°C)
- **Steps** (daily step count)
- **SleepHours** (average hours of sleep per day)
- **WaterIntake** (liters per day)
- **SweatRate** (liters per hour)
- **UrineColor** (scale of 1 to 8)
- **FatigueLevel** (scale of 1 to 10)

**Target:** HydrationStatus (`Well`, `Borderline`, `Dehydrated`)

---

## ⚙️ Model Pipeline

### 1. **Preprocessing**
- Label Encoding for categorical features
- Standardization of numerical features

### 2. **Model Training**
- Trained two models:
  - **Random Forest Classifier**
  - **XGBoost Classifier**

### 3. **Evaluation**
- Accuracy
- Confusion Matrix
- Classification Report
- Feature Importance Visualization

---

## 📊 Performance Summary
Both models performed well on the synthetic data with reasonable classification accuracy. Key influential features were:
- **Urine Color**
- **Sweat Rate**
- **Water Intake**
- **Heart Rate**

---

## 💡 Optional: Integration with Digital Twin
This model can be integrated into a **Digital Twin** for a human health monitoring system:
- Real-time tracking of hydration levels via wearable sensors
- Predictive alerts for dehydration risk
- Integration with mobile apps for health feedback

Example use cases:
- **Athletes** and **military personnel**
- **Elderly** individuals in assisted living
- **Smart wellness** applications

---

## 🛠️ Requirements
- Python 3.8+
- scikit-learn
- xgboost
- seaborn
- matplotlib

---

## 📁 Deliverables
- `hydration_prediction.ipynb` – Model notebook with preprocessing, training, and evaluation
- `README.md` – This documentation file

---

## 👤 Author
- Prepared for: AI/ML Engineer Internship Task
- Candidate: [Your Name Here]
- Date: May 2025
